export const usuarioData = {
    usuarioPorfolio : "gaston.alejandro.gmz@gmail.com"
}
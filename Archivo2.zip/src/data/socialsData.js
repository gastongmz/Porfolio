export const socialsData = {
    github: 'https://github.com/gastongmz',
    //facebook: 'https://www.facebook.com/',
    linkedIn: 'https://www.linkedin.com/in/gaston-alejandro-gomez/',
    instagram: 'https://www.instagram.com/gastongmz/',
    //codepen: 'https://codepen.io/',
    twitter: 'https://twitter.com/',
    //reddit: 'https://www.reddit.com/user/',
    //blogger: 'https://www.blogger.com/',
    //medium: 'https://medium.com/@',
    stackOverflow: 'https://stackoverflow.com/users/4035531/gastongmz',
    //gitlab: 'https://gitlab.com/',
    //youtube: 'https://youtube.com/'
}
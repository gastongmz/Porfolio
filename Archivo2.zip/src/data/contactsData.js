export const contactsData = {
    email: 'gaston.alejandro.gmz@gmail.com',
    phone: '+541115----',
    address: 'Canning, Buenos Aires, Argentina - 1134 ',

    sheetAPI: ''
}
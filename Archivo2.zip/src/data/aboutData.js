export const aboutData = {
    title: "Sobre mi",
    //description1: "My name's Jane. I'm a web designer and developer based in Southampton, UK.",
    description1: "Soy programador con más de 10 años de experiencia desarrollando tecnologías de software. Me considero una persona flexible y proactiva con gran capacidad analítica. Me he especializado en el desarrollo de aplicaciones web (ASP .NET MVC Framework, .NET Core, Angular) y aplicaciones móviles.",
    image: 1
}
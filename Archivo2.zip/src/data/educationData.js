export const educationData = [
    {
        id: 1,
        institution: 'Universidad Argentina de la Empresa',
        course: 'Licenciatura en Sistemas',
        startYear: '2020',
        endYear: 'En curso'
    },
    {
        id: 2,
        institution: 'Universidad Argentina de la Empresa',
        course: 'Metodologías ágiles Scrum',
        startYear: '2015',
        endYear: '2015'
    },
    {
        id: 3,
        institution: 'Fundación Proydesa',
        course: 'Ethical Hacking',
        startYear: '2019',
        endYear: '2019'
    },
    {
        id: 4,
        institution: 'Shiftseven',
        course: 'Design Sprint BootCamp',
        startYear: '2020',
        endYear: '2020'
    }
]